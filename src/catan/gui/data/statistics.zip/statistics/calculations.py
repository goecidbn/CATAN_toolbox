"""
Module for calculating statistics from data
"""

from __future__ import annotations

from typing import TYPE_CHECKING
from collections.abc import Callable


import numpy as np
from scipy import sparse, spatial

from event_estimator import get_events

from catan.core.image_correlation import calculate_img_correlation
from catan.core.spatial_coverage import (
    session_valid_mask,
    signed_border_distance,
    distances_at_centroids,
)

from catan.gui.background_tasks.runtime import current_task_context

if TYPE_CHECKING:
    from catan.gui.structures.state import AppState
    from catan.gui.structures.data import Data


def apply_indexers(
    values: np.ndarray,
    dims: tuple[str, ...],
    indexers: dict[str, int] | None = None,
):
    indexers = indexers or {}

    selection = tuple(indexers.get(dim, slice(None)) for dim in dims)

    return values[selection]


def requested_indices(
    size: int,
    dim: str,
    indexers: dict[str, int],
) -> np.ndarray:
    if dim in indexers:
        return np.asarray([indexers[dim]], dtype=int)

    return np.arange(size, dtype=int)


def drop_indexed_axes(
    values: np.ndarray,
    dims: tuple[str, ...],
    indexers: dict[str, int],
):
    """
    Used when the calculation itself was already restricted to indexed
    dimensions, so those axes now have length 1.
    """
    axes = tuple(axis for axis, dim in enumerate(dims) if dim in indexers)

    if axes:
        values = np.squeeze(values, axis=axes)

    return values


def get_stat_from_session(
    data: Data,
    state: AppState,
    indexers: dict[str, int] | None,
    get_stat: Callable,
):
    indexers = indexers or {}

    N, S = state.assignments.shape

    neuron_ids = requested_indices(N, "neuron", indexers)
    session_ids = requested_indices(S, "session", indexers)

    values = np.full(
        (len(neuron_ids), len(session_ids)),
        np.nan,
    )

    for j, session_id in enumerate(session_ids):

        fp_ids = state.assignments[neuron_ids, session_id]
        present = fp_ids >= 0

        # Registered-but-untracked sessions deliberately
        # have an empty assignment column.
        if not np.any(present):
            continue

        session = data.sessions[session_id]
        stat_session = get_stat(session)

        if stat_session is None:
            continue

        values[present, j] = stat_session[fp_ids[present]]

    return drop_indexed_axes(
        values,
        ("neuron", "session"),
        indexers,
    )


def get_quality_metric(
    data: Data,
    state: AppState,
    indexers: dict[str, int] | None = None,
    filters=(),
    **kwargs,
) -> np.ndarray:
    """
    Get a quality metric from the data.

    Parameters:
    key (str): The key of the quality metric to retrieve.

    Returns:
    np.ndarray: The requested quality metric.
    """
    indexers = indexers or {}
    key = kwargs.get("key", None)  # Default to 'snr' if no key is provided
    if key is None:
        raise ValueError("A 'key' must be provided to retrieve a quality metric.")

    # print(f"Retrieving quality metric '{key}' with indexers: {indexers}")

    def get_stat(session):
        return session.quality.get(key)

    return get_stat_from_session(data, state, indexers, get_stat)


def get_match_metric(
    data,
    state,
    indexers=None,
    filters=(),
    *,
    key: str,
    dims: tuple[str, ...],
):
    values = np.asarray(data.assignments.stats[key])

    return apply_indexers(
        values,
        dims,
        indexers,
    )


def normalize_csc_columns_to_max(A):

    A = A.tocsc(copy=True)

    if A.shape[0] == 0 or A.shape[1] == 0:
        return A

    col_max = A.max(axis=0).toarray().ravel()
    col_max = np.asarray(col_max, dtype=A.dtype)

    scale = np.ones(A.shape[1], dtype=A.dtype)

    nonzero = col_max > 0
    scale[nonzero] = 1.0 / col_max[nonzero]

    for j in range(A.shape[1]):
        start, end = (A.indptr[j], A.indptr[j + 1])

        A.data[start:end] *= scale[j]

    return A


def calculate_footprint_size(
    data: Data,
    state: AppState,
    indexers: dict[str, int] | None = None,
    filters=(),
    thr=0.01,
) -> np.ndarray:
    """
    Calculate the size of each footprint.

    Returns:
    np.ndarray: 1D array of footprint sizes.
    """
    indexers = indexers or {}

    def get_size(session):
        footprints: sparse.csc_matrix = session.footprints
        footprints = normalize_csc_columns_to_max(footprints)

        return (footprints > thr).getnnz(axis=0)

    return get_stat_from_session(data, state, indexers, get_size)


def calculate_temporal_correlation(
    data,
    state,
    indexers=None,
    filters=(),
    key="C",
):
    indexers = indexers or {}

    N, S = state.assignments.shape

    neuron_i = requested_indices(N, "neuron_i", indexers)
    neuron_j = requested_indices(N, "neuron_j", indexers)
    sessions = requested_indices(S, "session", indexers)

    values = np.full(
        (
            len(neuron_i),
            len(neuron_j),
            len(sessions),
        ),
        np.nan,
    )

    for k, session_id in enumerate(sessions):
        session = data.sessions[session_id]

        if session is None or key not in session.traces:
            continue

        fp_i = state.assignments[neuron_i, session_id]
        fp_j = state.assignments[neuron_j, session_id]

        valid_i = fp_i >= 0
        valid_j = fp_j >= 0

        if not valid_i.any() or not valid_j.any():
            continue

        ctx = current_task_context()
        if ctx is not None:
            ctx.check_cancelled()

        source = session.traces[key]

        def normalized_rows(indices):
            # Advanced indexing creates an owned array, so these
            # in-place operations cannot modify session traces.
            rows = source[indices].astype(
                np.result_type(source.dtype, np.float32),
                copy=False,
            )

            rows -= rows.mean(axis=1, keepdims=True)

            lengths = np.sqrt(np.einsum("ij,ij->i", rows, rows))

            with np.errstate(divide="ignore", invalid="ignore"):
                rows /= lengths[:, None]

            return rows

        ids_i = fp_i[valid_i]
        ids_j = fp_j[valid_j]

        ti = normalized_rows(ids_i)
        tj = ti if np.array_equal(ids_i, ids_j) else normalized_rows(ids_j)

        rows_i = np.flatnonzero(valid_i)
        rows_j = np.flatnonzero(valid_j)

        # Pearson correlation of centred, unit-normalized traces.
        # Calculate a row block at a time.
        for start in range(0, len(rows_i), 256):
            if ctx is not None:
                ctx.check_cancelled()

            stop = min(start + 256, len(rows_i))
            corr = ti[start:stop] @ tj.T

            values[np.ix_(rows_i[start:stop], rows_j, [k])] = corr[..., None]

            del corr

        del ti, tj

    return drop_indexed_axes(
        values,
        ("neuron_i", "neuron_j", "session"),
        indexers,
    )


def calculate_event_rate(
    data: Data,
    state: AppState,
    indexers: dict[str, int] | None = None,
    filters: tuple | None = (),
    key: str = "S_dff",
    prctile: float = 20,
):

    indexers = indexers or {}

    def _get_events(session):
        return get_events(session.traces[key], f=15.0, Ns_thr=1, prctile=prctile)

    return get_stat_from_session(
        data,
        state,
        indexers,
        _get_events,
    )


def calculate_distances(
    data: Data,
    state: AppState,
    indexers: dict[str, int] | None = None,
    filters=(),
):
    indexers = indexers or {}

    N, S = state.assignments.shape

    neuron_i = requested_indices(N, "neuron_i", indexers)
    neuron_j = requested_indices(N, "neuron_j", indexers)
    sessions = requested_indices(S, "session", indexers)

    values = np.full(
        (
            len(neuron_i),
            len(neuron_j),
            len(sessions),
        ),
        np.nan,
    )

    for k, session_id in enumerate(sessions):
        session = data.sessions[session_id]

        if session is None or session.centroids is None:
            continue

        fp_i = state.assignments[neuron_i, session_id]
        fp_j = state.assignments[neuron_j, session_id]

        valid_i = fp_i >= 0
        valid_j = fp_j >= 0

        if not valid_i.any() or not valid_j.any():
            continue

        ctr_i = session.centroids[fp_i[valid_i]]
        ctr_j = session.centroids[fp_j[valid_j]]

        dist = spatial.distance.cdist(
            ctr_i,
            ctr_j,
        )

        values[
            np.ix_(
                valid_i,
                valid_j,
                [k],
            )
        ] = dist[..., None]

    # self-pairs
    for ii, n_i in enumerate(neuron_i):
        matches = np.where(neuron_j == n_i)[0]

        values[ii, matches, :] = np.nan

    return drop_indexed_axes(
        values,
        ("neuron_i", "neuron_j", "session"),
        indexers,
    )


def calculate_border_proximity(
    data,
    state,
    indexers=None,
    filters=(),
    common_border=False,
):
    common_distance = None

    def check_alignment_current(session_id):
        if data.alignment_is_stale(session_id):
            raise ValueError(
                f"Session {session_id} has an outdated alignment. "
                "Rerun alignment before calculating border distance."
            )

    if common_border:
        # "Shared" always means all loaded sessions, independently
        # of the statistic's session reduction or selected session.
        for session_id in range(len(data.sessions)):
            check_alignment_current(session_id)

        _, common_distance = data.assignments.common_spatial_coverage(
            data.sessions,
            revision=getattr(state, "data_version", None),
        )

    session_ids = {
        id(session): session_id for session_id, session in enumerate(data.sessions)
    }

    def get_distances(session):
        if common_distance is not None:
            distance_map = common_distance
        else:
            check_alignment_current(session_ids[id(session)])

            distance_map = signed_border_distance(session_valid_mask(session))

        return distances_at_centroids(session, distance_map)

    return get_stat_from_session(
        data,
        state,
        indexers,
        get_distances,
    )


def calculate_occurrence(
    data,
    state,
    indexers=None,
    filters=(),
):
    selected = apply_indexers(
        state.assignments,
        ("neuron", "session"),
        indexers,
    )
    return selected >= 0


def calculate_centroid_shift(
    data: Data,
    state: AppState,
    indexers: dict[str, int] | None = None,
    filters=(),
) -> np.ndarray:

    indexers = indexers or {}

    N, S = state.assignments.shape

    neuron_ids = requested_indices(N, "neuron", indexers)
    session_i_ids = requested_indices(S, "session_i", indexers)
    session_j_ids = requested_indices(S, "session_j", indexers)

    coords_i = np.full(
        (len(neuron_ids), len(session_i_ids), 2),
        np.nan,
    )

    coords_j = np.full(
        (len(neuron_ids), len(session_j_ids), 2),
        np.nan,
    )

    def fill_coords(
        target: np.ndarray,
        session_ids: np.ndarray,
    ):
        for k, session_id in enumerate(session_ids):
            session = data.sessions[session_id]

            if session is None or session.centroids is None:
                continue

            # global neuron ID -> local footprint ID
            fp_ids = state.assignments[
                neuron_ids,
                session_id,
            ]

            present = fp_ids >= 0

            target[present, k, :] = session.centroids[fp_ids[present], :]

    fill_coords(
        coords_i,
        session_i_ids,
    )

    fill_coords(
        coords_j,
        session_j_ids,
    )

    # neuron × session_i × session_j
    values = np.linalg.norm(
        coords_i[:, :, None, :] - coords_j[:, None, :, :],
        axis=-1,
    )

    return drop_indexed_axes(
        values,
        (
            "neuron",
            "session_i",
            "session_j",
        ),
        indexers,
    )


def calculate_footprint_similarity(
    data,
    state,
    indexers=None,
    filters=(),
    neighborhood_thr=10,
    gamma=0.1,
):
    from .footprint_pairs import calculate_footprint_pairs

    return calculate_footprint_pairs(
        data,
        state,
        indexers=indexers,
        filters=filters,
        neighborhood_thr=neighborhood_thr,
        gamma=gamma,
    )


def get_pair_relation(
    filters,
    target: str,
) -> str:
    for f in filters:
        if f.target == target:
            return f.relation

    return "all"
