from typing import Literal, Optional
from dataclasses import dataclass, replace

from .dimensions import (
    canonical_dim,
    SESSION_DIMS,
    NEURON_DIMS,
    neuron_bound_dim,
    component_bound_dims,
    neuron_pair_bound_dims,
    component_pair_bound_dims,
)

Contexts = Literal[
    "generic",
    "session_series",
    "neuron_bound",
    "component_bound",
    "neuron_pair_bound",
    "component_pair_bound",
]

ReductionMethod = Literal[
    "keep",
    "single",
    "mean",
    "median",
    "max",
    "min",
    "sum",
    "std",
]

ErrorMethod = Literal[
    "none",
    "std",
    "sem",
    "iqr",
    "bootstrap",
]

DEFAULT_REDUCTIONS = ("keep", "single", "mean", "median", "max", "min", "sum", "std")

REDUCTION_METHODS = {
    "generic": {
        "session": DEFAULT_REDUCTIONS,
        "neuron": DEFAULT_REDUCTIONS,
        "default": DEFAULT_REDUCTIONS,
    },
    "session_series": {
        "session": ("keep", "single"),
        "neuron": ("mean", "median", "sum"),
        "default": ("single", "mean", "median", "max", "min"),
    },
    "neuron_bound": {
        "neuron": DEFAULT_REDUCTIONS,
        "default": DEFAULT_REDUCTIONS,
    },
    "component_bound": {
        "neuron": DEFAULT_REDUCTIONS,
        "session": DEFAULT_REDUCTIONS,
        "default": DEFAULT_REDUCTIONS,
    },
    "neuron_pair_bound": {
        "neuron": DEFAULT_REDUCTIONS,
        "session": DEFAULT_REDUCTIONS,
        "default": DEFAULT_REDUCTIONS,
    },
    "component_pair_bound": {
        "neuron": DEFAULT_REDUCTIONS,
        "session": DEFAULT_REDUCTIONS,
        "default": DEFAULT_REDUCTIONS,
    },
}

ERROR_METHODS = {
    "generic": {
        "session": {
            "mean": ("none", "std", "sem", "iqr", "bootstrap"),
            "median": ("none", "iqr", "bootstrap"),
            "max": ("none", "bootstrap"),
            "min": ("none", "bootstrap"),
            "sum": ("none", "bootstrap"),
            "std": ("none", "bootstrap"),
        },
        "neuron": {
            "mean": ("none", "std", "sem", "iqr", "bootstrap"),
            "median": ("none", "iqr", "bootstrap"),
            "max": ("none", "bootstrap"),
            "min": ("none", "bootstrap"),
            "sum": ("none", "bootstrap"),
            "std": ("none", "bootstrap"),
        },
        "default": {
            "mean": ("none", "std", "sem", "iqr", "bootstrap"),
            "median": ("none", "iqr", "bootstrap"),
            "max": ("none", "bootstrap"),
            "min": ("none", "bootstrap"),
            "sum": ("none", "bootstrap"),
            "std": ("none", "bootstrap"),
        },
    },
    "session_series": {
        "session": {},
        "neuron": {
            "mean": ("std", "sem", "bootstrap"),
            "median": ("iqr", "bootstrap"),
            "sum": ("none",),
        },
        "default": {
            "mean": ("none",),
            "median": ("none",),
            "max": ("none",),
            "min": ("none",),
            "sum": ("none",),
            "std": ("none",),
        },
    },
}
# lazy adding
ERROR_METHODS["neuron_bound"] = ERROR_METHODS["generic"]
ERROR_METHODS["component_bound"] = ERROR_METHODS["generic"]
ERROR_METHODS["neuron_pair_bound"] = ERROR_METHODS["generic"]
ERROR_METHODS["component_pair_bound"] = ERROR_METHODS["generic"]


PairRelation = Literal["all", "same", "different", "with previous"]
PairTarget = Literal["neuron", "session"]


@dataclass(frozen=True, slots=True)
class PairFilter:
    target: PairTarget
    relation: PairRelation
    collapse_same: bool = True


@dataclass(frozen=True, slots=True)
class ReductionSpec:
    ## defines reduction for each dimension
    method: ReductionMethod
    index: Optional[int] = None
    error_method: ErrorMethod = "none"


@dataclass(frozen=True, slots=True)
class StatisticQuery:
    statistic_key: str
    reductions: tuple[tuple[str, ReductionSpec], ...]
    reduction_order: tuple[str, ...] = ()
    filters: tuple[PairFilter, ...] = ()
    context: Contexts = "generic"

    def reduction_dict(self):
        return dict(self.reductions)

    def to_dict(self) -> dict:
        return {
            "statistic_key": self.statistic_key,
            "reductions": {
                dim: {
                    "method": spec.method,
                    "index": spec.index,
                    "error_method": spec.error_method,
                }
                for dim, spec in self.reductions
            },
            "reduction_order": list(self.reduction_order),
            "filters": [
                {
                    "target": f.target,
                    "relation": f.relation,
                    "collapse_same": f.collapse_same,
                }
                for f in self.filters
            ],
            "context": self.context,
        }

    @classmethod
    def from_dict(
        cls,
        data: dict,
    ) -> "StatisticQuery":

        return cls(
            statistic_key=data["statistic_key"],
            reductions=tuple(
                sorted(
                    (
                        dim,
                        ReductionSpec(
                            method=spec["method"],
                            index=spec.get("index"),
                            error_method=spec.get("error_method", "none"),
                        ),
                    )
                    for dim, spec in data.get(
                        "reductions",
                        {},
                    ).items()
                )
            ),
            reduction_order=tuple(data.get("reduction_order", ())),
            filters=tuple(
                PairFilter(
                    target=f["target"],
                    relation=f["relation"],
                    collapse_same=f.get("collapse_same", True),
                )
                for f in data.get("filters", ())
            ),
            context=data.get("context", "generic"),
        )


def statistic_allowed_in_context(
    dims: tuple[str, ...],
    context: Contexts,
):
    if context == "neuron_bound":
        return neuron_bound_dim(dims) is not None

    if context == "component_bound":
        return component_bound_dims(dims) is not None

    if context == "neuron_pair_bound":
        return neuron_pair_bound_dims(dims) is not None

    if context == "component_pair_bound":
        return component_pair_bound_dims(dims) is not None

    return True


def allowed_reduction_methods(
    dim_name: str,
    *,
    context: Contexts = "generic",
) -> tuple[str, ...]:
    """
    gets allowed reduction methods for a given dimension name and context
    """
    kind = canonical_dim(dim_name)

    context_methods = REDUCTION_METHODS.get(
        context,
        REDUCTION_METHODS["generic"],
    )

    return context_methods.get(
        kind,
        context_methods.get("default", DEFAULT_REDUCTIONS),
    )


def allowed_error_methods(
    dim_name: str,
    reduction_method: str,
    *,
    context: Contexts = "generic",
) -> tuple[str, ...]:
    if reduction_method in ("keep", "single"):
        return ("none",)

    kind = canonical_dim(dim_name)

    context_methods = ERROR_METHODS.get(
        context,
        ERROR_METHODS["generic"],
    )

    dim_methods = context_methods.get(
        kind,
        context_methods.get("default", {}),
    )

    return dim_methods.get(reduction_method, ("none",))


def validate_error_reductions(reductions: dict[str, ReductionSpec]):
    error_dims = [
        dim for dim, spec in reductions.items() if spec.error_method != "none"
    ]

    if len(error_dims) > 1:
        raise ValueError(
            "Only one error-producing reduction is currently supported. "
            f"Got error reductions on {error_dims}."
        )


def normalize_footprint_pair_reductions(
    stat_def, reductions, filters=(), *, session_series=False,
):
    """One reduction per logical axis, before any values are calculated.

    The i side controls a collapsed pair. The hidden j side mirrors it,
    except that a fixed previous session uses i-1. Non-linked axes remain
    independent. Existing queries are upgraded deterministically.
    """
    out = {d: reductions.get(d, ReductionSpec("keep")) for d in stat_def.dims}
    relations = {f.target: f.relation for f in filters}
    collapse = {f.target: f.collapse_same for f in filters}
    linked = {
        "neuron": relations.get("neuron") == "same" and collapse.get("neuron", True),
        "session": relations.get("session") in ("same", "with previous") and collapse.get("session", True),
    }

    if session_series:
        if linked["session"]:
            out["session_i"] = out["session_j"] = ReductionSpec("keep")
        else:
            kept = [d for d in ("session_i", "session_j") if out[d].method == "keep"]
            if not kept:
                out["session_i"] = ReductionSpec("keep")
            elif len(kept) == 2:
                out["session_j"] = ReductionSpec("single", index=0)

        logical_neurons = ["neuron_i"] if linked["neuron"] else ["neuron_i", "neuron_j"]
        for d in logical_neurons:
            if out[d].method == "keep":
                out[d] = ReductionSpec("median", error_method="none")
        # Upgrade the previous two-neuron-axis series default. Interactive
        # edits mirror both settings before normalization, so choosing
        # 'none' on the visible axis remains possible.
        if linked["neuron"] and out["neuron_i"].error_method == "none":
            old = out["neuron_j"]
            if old.method == out["neuron_i"].method:
                out["neuron_i"] = replace(out["neuron_i"], error_method=old.error_method)

    for target in ("neuron", "session"):
        if not linked[target]:
            continue
        left, right = target + "_i", target + "_j"
        spec = out[left]
        if spec.method == "single":
            index = int(spec.index) if spec.index is not None else 0
            previous = target == "session" and relations.get(target) == "with previous"
            index = max(1 if previous else 0, index)
            out[left] = ReductionSpec("single", index=index)
            out[right] = ReductionSpec("single", index=index - int(previous))
        else:
            out[right] = spec

    # Validate logical axes, not duplicated names of one collapsed axis.
    logical = {d: spec for d, spec in out.items()
               if not (d.endswith("_j") and linked.get(d[:-2], False))}
    validate_error_reductions(logical)
    return out


def normalize_session_series_reductions(
    stat_def,
    reductions: dict[str, ReductionSpec],
    filters: tuple[PairFilter, ...] = (),
) -> dict[str, ReductionSpec]:

    if stat_def.key == "footprint_similarity":
        return normalize_footprint_pair_reductions(
            stat_def, reductions, filters, session_series=True,
        )

    out = dict(reductions)

    session_dims = [d for d in stat_def.dims if d in SESSION_DIMS]
    neuron_dims = [d for d in stat_def.dims if d in NEURON_DIMS]

    session_relation = next(
        (f.relation for f in filters if f.target == "session"),
        "all",
    )

    # ----- session dimensions -----

    if len(session_dims) == 1:
        # This IS the x-axis of a session series.
        out[session_dims[0]] = ReductionSpec("keep")

    elif len(session_dims) == 2:
        dim_i = "session_i" if "session_i" in session_dims else session_dims[0]
        dim_j = "session_j" if "session_j" in session_dims else session_dims[1]

        if session_relation in ("same", "with previous"):
            # Both are needed until the pair filter is applied.
            # Afterwards they collapse into one session dimension.
            out[dim_i] = ReductionSpec("keep")
            out[dim_j] = ReductionSpec("keep")

        else:
            # session_i is the series axis;
            # session_j is one selected comparison session.
            out[dim_i] = ReductionSpec("keep")

            old = out.get(
                dim_j,
                ReductionSpec("single", index=0),
            )

            out[dim_j] = ReductionSpec(
                "single",
                index=old.index or 0,
            )

    # ----- neuron dimensions -----

    # Only ONE neuron reduction may create errors.
    error_dim = neuron_dims[-1] if neuron_dims else None

    for dim in neuron_dims:
        old = out.get(
            dim,
            ReductionSpec("median"),
        )

        allowed_methods = allowed_reduction_methods(
            dim,
            context="session_series",
        )
        method = (
            old.method if old.method in allowed_methods else "median"
        )

        if dim != error_dim:
            error_method = "none"

        else:
            allowed_errors = allowed_error_methods(
                dim,
                method,
                context="session_series",
            )

            if old.error_method in allowed_errors:
                error_method = old.error_method
            else:
                default_error = {
                    "median": "iqr",
                    "mean": "sem",
                }.get(method, "none")

                error_method = (
                    default_error
                    if default_error in allowed_errors
                    else "none"
                )

        out[dim] = ReductionSpec(
            method,
            error_method=error_method,
        )

    # ----- other dimensions -----

    for dim in stat_def.dims:
        if dim in session_dims or dim in neuron_dims:
            continue

        old = out.get(
            dim,
            ReductionSpec("single", index=0),
        )

        allowed = allowed_reduction_methods(
            dim,
            context="session_series",
        )

        if old.method in allowed:
            method = old.method
        elif "single" in allowed:
            method = "single"
        else:
            method = allowed[0]

        out[dim] = ReductionSpec(
            method,
            index=(
                old.index
                if method == "single" and old.index is not None
                else 0 if method == "single" else None
            ),
            error_method="none",
        )

    validate_error_reductions(out)

    return out


def normalize_generic_session_pair_reductions(
    stat_def,
    reductions,
    filters,
):
    if stat_def.key == "footprint_similarity":
        return normalize_footprint_pair_reductions(stat_def, reductions, filters)

    out = dict(reductions)

    if not {"session_i", "session_j"}.issubset(stat_def.dims):
        return out

    relation = next(
        (f.relation for f in filters if f.target == "session"),
        "all",
    )

    # These relations constrain valid pairs without forcing reductions.
    if relation not in ("same", "with previous"):
        return out

    source = out.get("session_i", ReductionSpec("keep"))

    if source.method == "single":
        index = int(source.index) if source.index is not None else 0

        if relation == "with previous":
            index = max(1, index)
            reference_index = index - 1
        else:
            reference_index = index

        out["session_i"] = ReductionSpec("single", index=index)
        out["session_j"] = ReductionSpec(
            "single",
            index=reference_index,
        )
    else:
        # Retain both axes until the pair filter selects and collapses
        # the linked pairs into one session dimension.
        out["session_i"] = ReductionSpec("keep")
        out["session_j"] = ReductionSpec("keep")

    return out


def normalize_neuron_bound_reductions(
    stat_def,
    reductions,
):
    out = dict(reductions)

    output_dim = neuron_bound_dim(stat_def.dims)

    if output_dim is None:
        raise ValueError(f"{stat_def.key!r} cannot produce neuron-bound data.")

    for dim in stat_def.dims:

        if dim == output_dim:
            out[dim] = ReductionSpec("keep")
            continue

        spec = out.get(dim)

        allowed = stat_def.get_allowed_reductions(dim)
        allowed = tuple(method for method in allowed if method != "keep")

        # Preserve an already valid choice
        if spec is not None and spec.method in allowed:
            out[dim] = replace(
                spec,
                error_method="none",
            )
            continue

        # Sensible fallback
        if dim in NEURON_DIMS and "median" in allowed:
            out[dim] = ReductionSpec("median")

        elif "single" in allowed:
            out[dim] = ReductionSpec(
                "single",
                index=0,
            )

        elif "median" in allowed:
            out[dim] = ReductionSpec("median")

        elif "mean" in allowed:
            out[dim] = ReductionSpec("mean")

        else:
            raise ValueError(
                f"Dimension {dim!r} cannot be reduced " "for neuron-bound output."
            )

    return out


def normalize_component_bound_reductions(
    stat_def,
    reductions,
):
    """
    Normalize a query so its output remains bound to one component.

    Ordinary statistic:
        neuron + session remain

    Pair statistic:
        prefer neuron_i + session_i
        neuron_j / session_j and all other dimensions disappear
    """

    out = dict(reductions)

    bound = component_bound_dims(stat_def.dims)

    if bound is None:
        raise ValueError(f"{stat_def.key!r} cannot produce component-bound data.")

    neuron_dim, session_dim = bound

    keep_dims = {neuron_dim}

    if session_dim is not None:
        keep_dims.add(session_dim)

    for dim in stat_def.dims:

        allowed = stat_def.get_allowed_reductions(dim)
        spec = out.get(dim)

        # -----------------------------------------
        # The neuron identity MUST survive.
        # -----------------------------------------
        if dim == neuron_dim:
            out[dim] = ReductionSpec("keep")
            continue

        # -----------------------------------------
        # The associated session dimension MAY
        # survive.
        #
        # Default = keep, because footprint mode
        # normally wants component-specific values.
        # But the user may deliberately reduce it.
        # -----------------------------------------
        if dim == session_dim:

            if spec is not None and spec.method in allowed:
                out[dim] = replace(spec, error_method="none")
            else:
                out[dim] = ReductionSpec("keep")

            continue

        # -----------------------------------------
        # Every other dimension MUST disappear.
        # -----------------------------------------
        allowed = tuple(method for method in allowed if method != "keep")

        if spec is not None and spec.method in allowed:
            out[dim] = replace(spec, error_method="none")
            continue

        if dim in NEURON_DIMS and "median" in allowed:
            out[dim] = ReductionSpec("median")

        elif dim in SESSION_DIMS and "single" in allowed:
            out[dim] = ReductionSpec("single", index=0)

        elif "single" in allowed:
            out[dim] = ReductionSpec("single", index=0)

        elif "median" in allowed:
            out[dim] = ReductionSpec("median")

        elif "mean" in allowed:
            out[dim] = ReductionSpec("mean")

        else:
            raise ValueError(
                f"Dimension {dim!r} cannot be reduced " "for component-bound output."
            )

    return out


def normalize_neuron_pair_bound_reductions(
    stat_def,
    reductions,
):
    out = dict(reductions)

    neuron_dims = neuron_pair_bound_dims(stat_def.dims)

    if neuron_dims is None:
        raise ValueError(f"{stat_def.key!r} cannot produce neuron-pair-bound data.")

    keep_dims = set(neuron_dims)

    for dim in stat_def.dims:

        allowed = stat_def.get_allowed_reductions(dim)
        spec = out.get(dim)

        # Both neuron identities define the table row.
        if dim in keep_dims:
            out[dim] = ReductionSpec("keep")
            continue

        # Everything else must disappear.
        allowed = tuple(method for method in allowed if method != "keep")

        if spec is not None and spec.method in allowed:
            out[dim] = replace(spec, error_method="none")
            continue

        if dim in SESSION_DIMS and "single" in allowed:
            out[dim] = ReductionSpec("single", index=0)

        elif dim in NEURON_DIMS and "median" in allowed:
            out[dim] = ReductionSpec("median")

        elif "single" in allowed:
            out[dim] = ReductionSpec("single", index=0)

        elif "median" in allowed:
            out[dim] = ReductionSpec("median")

        elif "mean" in allowed:
            out[dim] = ReductionSpec("mean")

        else:
            raise ValueError(
                f"Dimension {dim!r} cannot be reduced " "for neuron-pair-bound output."
            )

    return out


def normalize_component_pair_bound_reductions(
    stat_def,
    reductions,
):
    out = dict(reductions)

    bound = component_pair_bound_dims(stat_def.dims)

    if bound is None:
        raise ValueError(
            f"{stat_def.key!r} cannot produce " "component-pair-bound data."
        )

    neuron_dims, session_dims = bound

    neuron_dims = set(neuron_dims)
    session_dims = set(session_dims)

    for dim in stat_def.dims:

        allowed = stat_def.get_allowed_reductions(dim)
        spec = out.get(dim)

        # Pair identity MUST survive.
        if dim in neuron_dims:
            out[dim] = ReductionSpec("keep")
            continue

        # Session identity MAY survive.
        if dim in session_dims:

            if spec is not None and spec.method in allowed:
                out[dim] = replace(spec, error_method="none")
            else:
                # Footprint-pair default:
                # stay specific to the concrete components.
                out[dim] = ReductionSpec("keep")

            continue

        # Everything unrelated to the pair must disappear.
        allowed = tuple(method for method in allowed if method != "keep")

        if spec is not None and spec.method in allowed:
            out[dim] = replace(spec, error_method="none")
            continue

        if dim in NEURON_DIMS and "median" in allowed:
            out[dim] = ReductionSpec("median")

        elif dim in SESSION_DIMS and "single" in allowed:
            out[dim] = ReductionSpec("single", index=0)

        elif "single" in allowed:
            out[dim] = ReductionSpec("single", index=0)

        elif "median" in allowed:
            out[dim] = ReductionSpec("median")

        elif "mean" in allowed:
            out[dim] = ReductionSpec("mean")

        else:
            raise ValueError(
                f"Dimension {dim!r} cannot be reduced "
                "for component-pair-bound output."
            )

    return out
