from typing import Dict, Optional, Tuple
import textwrap
from dataclasses import dataclass
from catan.gui.data.statistics.queries import ReductionSpec
import numpy as np
from scipy import sparse
from vispy import scene, color
from vispy.scene import visuals
from vispy.scene.visuals import Markers, Image, Rectangle, Text

from PySide6.QtCore import Qt, Signal, Slot, QEvent
from PySide6.QtWidgets import (
    QApplication,
    QWidget,
    QComboBox,
    QCheckBox,
    QLabel,
    QInputDialog,
    QToolTip,
    QVBoxLayout,
    QToolButton,
    QFormLayout,
)

from catan.core.changes import (
    ChangeKind as C,
    DataChange,
    SESSION_STRUCTURE_CHANGES,
)
from catan.core.structures import NeuronComponent
from catan.gui.panels import BasePlot
from catan.gui.interaction import click_events

from catan.gui.data.statistics.dimensions import SESSION_DIMS, neuron_bound_dim
from catan.gui.panels.StatisticsData import StatisticQuerySelector
from catan.gui.panels.helper import ReviewStatusFilter, ControlPanel

STATISTIC_CMAPS = {
    "viridis": "viridis",
    "coolwarm": "coolwarm",
    "cubehelix": "cubehelix",
    "red-green": (
        "#b2182b",
        "#f2f2f2",
        "#1a9850",
    ),
    "blue-orange": (
        "#2166ac",
        "#f2f2f2",
        "#b35806",
    ),
}


@dataclass
class OverviewRecord:
    # visual: scene.Markers
    pos: np.ndarray
    ids: np.ndarray
    vals: np.ndarray
    n_rois: int
    color: list | tuple | str


class Display(BasePlot.BaseCanvas):

    main_visual = Markers
    main_visual_name = "marker"

    overlays = ["selected", "focused", "highlighted", "hovered"]

    def __init__(self, parent, controls, config=None):
        super().__init__(parent, controls, config)

        self.unfreeze()
        self.grid = self.central_widget.add_grid(spacing=0)
        self.view = self.grid.add_view(row=0, col=0)
        self.view.stretch = (1, 1)  # expand a lot
        ## set camera
        self.view.camera = scene.PanZoomCamera(aspect=None)
        self.view.camera.interactive = False

        self.plot_root = scene.Node(parent=self.view.scene)

        self.changes_on_click = "selected"

        self.control_overlay = None
        self.events.resize.connect(self._on_canvas_resize)

        self.neuron_statistic_values = None
        self.statistic_title = None

        self.statistic_cmap_name = "viridis"
        self.statistic_cmap_reversed = False

        self.statistic_cmap = self._make_statistic_colormap(
            self.statistic_cmap_name,
            self.statistic_cmap_reversed,
        )

        self.statistic_data_clim = None
        self.statistic_manual_clim = {
            "low": None,
            "high": None,
        }
        self.build_colorbar()

        self.statistic_nan_color = np.asarray(
            color.Color("#686868").rgba,
            dtype=np.float32,
        )
        self.statistic_nan_color[3] = 0.55

        self.freeze()

    def build_colorbar(self):

        self._cbar_size = (120, 10)
        self._cbar_center = (90, 20)
        cbar_size = self._cbar_size
        cbar_center = self._cbar_center
        cbar_hmargin = 15
        cbar_vmargin = 10

        self.statistic_colorbar_bg = Rectangle(
            center=(cbar_center[0], cbar_center[1] + 15),
            width=cbar_size[0] + 2 * cbar_hmargin,
            height=cbar_size[1] + 2 * cbar_vmargin + 30,
            color=(1.0, 1.0, 1.0, 0.78),
            border_color=None,
            parent=self.scene,
        )

        self.statistic_colorbar_bg.set_gl_state(
            depth_test=False,
            blend=True,
            blend_func=("src_alpha", "one_minus_src_alpha"),
        )
        self.statistic_colorbar_bg.order = 10000
        self.statistic_colorbar_bg.visible = False

        self.statistic_colorbar = visuals.ColorBar(
            cmap=self.statistic_cmap,
            orientation="bottom",
            size=self._cbar_size,
            pos=self._cbar_center,
            label="",
            clim=("", ""),
            border_width=1,
            border_color="black",
            parent=self.scene,
        )

        self.statistic_colorbar.order = 10001
        self.statistic_colorbar.visible = False

        label_y_offset = 25
        label_y = self._cbar_center[1] + label_y_offset

        left = self._cbar_center[0] - self._cbar_size[0] / 2
        right = self._cbar_center[0] + self._cbar_size[0] / 2

        self._cbar_low_label_pos = (left + 8, label_y)
        self._cbar_high_label_pos = (right - 8, label_y)

        # Slightly above the labels:
        self._cbar_low_reset_pos = (left + 22, label_y - 11)
        self._cbar_high_reset_pos = (right + 6, label_y - 11)

        self.statistic_colorbar_low = Text(
            "",
            pos=self._cbar_low_label_pos,
            anchor_x="center",
            anchor_y="top",
            font_size=9,
            color="black",
            parent=self.scene,
        )

        self.statistic_colorbar_high = Text(
            "",
            pos=self._cbar_high_label_pos,
            anchor_x="center",
            anchor_y="top",
            font_size=9,
            color="black",
            parent=self.scene,
        )

        self.statistic_colorbar_title = Text(
            "",
            pos=(cbar_center[0], cbar_center[1] + label_y_offset + 13),
            anchor_x="center",
            anchor_y="top",
            font_size=10,
            color="black",
            parent=self.scene,
        )

        self.statistic_colorbar_low_reset = Text(
            "×",
            pos=self._cbar_low_reset_pos,
            anchor_x="center",
            anchor_y="center",
            font_size=11,
            color="#707070",
            parent=self.scene,
        )

        self.statistic_colorbar_high_reset = Text(
            "×",
            pos=self._cbar_high_reset_pos,
            anchor_x="center",
            anchor_y="center",
            font_size=11,
            color="#707070",
            parent=self.scene,
        )

        for visual in (
            self.statistic_colorbar_low_reset,
            self.statistic_colorbar_high_reset,
        ):
            visual.order = 10003
            visual.visible = False

        for text in (
            self.statistic_colorbar_low,
            self.statistic_colorbar_high,
            self.statistic_colorbar_title,
        ):
            text.order = 10002
            text.visible = False

    def initialize_overlays(self):

        for style in ["selected", "focused", "highlighted", "hovered"]:
            self.add_overlay(style)

    def _on_canvas_resize(self, event=None):
        self._position_overlay_controls()

    def attach_control_overlay(self):
        """
        Attach the Trace control widgets to the canvas after
        Controller.build_controls() has created them.
        """

        control_overlay = self.controls.get("panel")

        if control_overlay is None:
            return

        self.control_overlay = control_overlay

        self.control_overlay.setParent(self.native)
        self.control_overlay.show()
        self.control_overlay.raise_()

        self.control_overlay.overlay_layout_changed.connect(
            self._position_overlay_controls
        )

        self._position_overlay_controls()

    def _position_overlay_controls(self):

        if self.control_overlay is None:
            return

        margin = 8
        spacing = 6

        palette = self.control_overlay
        palette.adjustSize()

        x = self.native.width() - palette.width() - margin

        palette.move(max(margin, x), margin)
        palette.raise_()

    def plot_background(self):

        if self.data.current_session is None:
            return

        ## remove previous background if exists
        if self.plotting.get("background") is not None:
            self.plotting["background"].parent = None
            del self.plotting["background"]

        background = self.data.current_session.background
        if background is None:
            return

        self.plotting["background"] = Image(
            background.astype(np.float32),  # .T,
            cmap="grays",
            method="subdivide",
            parent=self.plot_root,
        )
        self.plotting["background"].order = -1000  # ensure it's in the back
        self.plotting["background"].set_gl_state(depth_test=False, blend=False)

        H, W = background.shape[:2]
        self.view.camera.set_range(
            x=(0, W),
            y=(0, H),
            margin=0,
        )
        self.update()

    def clean_highlight(self):
        for _, visual in self.plotting["overlays"].items():
            if visual is None:
                continue
            visual.visible = False

    def build_neuron_visuals_union(self):

        if not self.data.is_available():
            return

        roi_pos, neuron_ids, roi_vals = sparse_A_to_points(
            self.data.assignments.union.footprints, self.data.sessions[0].dims, thr=0.5
        )

        self.plotting["data"]["union"] = OverviewRecord(
            pos=roi_pos,
            ids=neuron_ids,
            vals=roi_vals,
            n_rois=self.data.assignments.union.n_neurons,
            color=None,
        )

    def build_neuron_visuals_session(self, session_id: Optional[int] = None, thr=0.2):

        if session_id is None:
            session_id = self.state.current_session_id
        if (
            session_id is None
            or session_id >= len(self.data.sessions)
            or self.data.sessions[session_id] is None
            or not self.data.sessions[session_id].status["spatial_loaded"]
            or not self.data.session_assigned(session_id)
        ):
            return

        if self.display_mode == "tracked_overview" and "union" in self.plotting["data"]:
            present_neuron_ids = np.where(
                self.state.assignments[:, self.state.current_session_id] >= 0
            )[0]

            union = self.plotting["data"]["union"]

            mask = np.isin(union.ids, present_neuron_ids)

            roi_pos = union.pos[mask]
            roi_vals = union.vals[mask]
            neuron_ids = union.ids[mask]

            n_rois = len(present_neuron_ids)
        else:
            roi_pos, roi_ids, roi_vals = sparse_A_to_points(
                self.data.sessions[session_id].footprints,
                self.data.sessions[session_id].dims,
                thr=thr,
            )
            n_rois = self.data.sessions[session_id].footprints.get_shape()[1]

            footprint_to_component = np.array(
                [self.state.get_component_from_footprint(i) for i in range(n_rois)]
            )
            footprint_to_neuron_id = np.array(
                [c.neuron_id if c is not None else -1 for c in footprint_to_component]
            )
            neuron_ids = footprint_to_neuron_id[roi_ids]

        self.plotting["data"][session_id] = OverviewRecord(
            pos=roi_pos,
            ids=neuron_ids,
            vals=roi_vals,
            n_rois=n_rois,
            # color=self.state.session_colors[session_id],
            color="white",
        )

    def plot_neurons_visuals(self):

        for key, record in self.plotting["data"].items():

            if key in self.plotting["visuals"]:
                continue

            footprints = Markers(
                parent=self.plot_root,
                scaling="scene",
                symbol="square",
            )
            footprints.set_gl_state(
                depth_test=False,
                blend=True,
                blend_func=(
                    "src_alpha",
                    "one_minus_src_alpha",
                ),  # Make overlaps visible
            )

            # record = self.plotting["data"][key]

            # colors, style = self._colors_for_record(
            #     key,
            #     record,
            # )

            # plot_options = self.styles.get_plot_options(
            #     style=style,
            #     plot_type="marker",
            #     values=record.vals,
            #     colors=colors,
            #     edge_width=0,
            # )

            footprints.set_data(record.pos)  # , **plot_options)

            if key == "union":
                footprints.order = 0
            else:
                footprints.order = 1
            self.plotting["visuals"][key] = footprints

        self._update_statistic_colors()

    def clean(self, with_union=True):

        for key, visual in self.plotting["visuals"].items():
            if visual is None or (not with_union and key == "union"):
                continue
            visual.visible = False
            visual.parent = None
        self.plotting["visuals"] = (
            {}
            if with_union
            else {k: v for k, v in self.plotting["visuals"].items() if k == "union"}
        )

        for key, data in self.plotting["data"].items():
            if not with_union and key == "union":
                continue
        self.plotting["data"] = (
            {}
            if with_union
            else {k: v for k, v in self.plotting["data"].items() if k == "union"}
        )
        # self.clear_overlays()

    # def clear_overlays(self):
    #     super().clear_overlays()
    #     self.initialize_overlays()

    ### ==================================================================== ###
    ### ======================= STATISTICS SECTION ========================= ###
    ### ==================================================================== ###

    def set_neuron_statistic_values(
        self,
        values,
        *,
        title=None,
    ):
        if not self.data.is_available():
            return

        self.neuron_statistic_values = (
            None if values is None else np.asarray(values, dtype=float)
        )

        self.statistic_title = title

        if self.neuron_statistic_values is None:
            self.statistic_data_clim = None

        else:
            finite = self.neuron_statistic_values[
                np.isfinite(self.neuron_statistic_values)
            ]

            self.statistic_data_clim = (
                None
                if finite.size == 0
                else (float(np.min(finite)), float(np.max(finite)))
            )

        self._update_statistic_colorbar()
        self._update_statistic_colors()

    def _effective_statistic_clim(self):

        if self.statistic_data_clim is None:
            return None

        data_lo, data_hi = self.statistic_data_clim

        manual_lo = self.statistic_manual_clim["low"]
        manual_hi = self.statistic_manual_clim["high"]

        lo = data_lo if manual_lo is None else manual_lo
        hi = data_hi if manual_hi is None else manual_hi

        # Possible if one bound is fixed and a newly displayed
        # dataset lies completely beyond that bound.
        if lo >= hi:

            if manual_lo is not None and manual_hi is None:
                hi = np.nextafter(lo, np.inf)

            elif manual_hi is not None and manual_lo is None:
                lo = np.nextafter(hi, -np.inf)

            # elif manual_lo is not None and manual_hi is not None:
            else:
                self.set_statistic_clim_limit("low", None)
                self.set_statistic_clim_limit("high", None)

            # else:
            # return None

        return float(lo), float(hi)

    def set_statistic_clim_limit(
        self,
        which: str,
        value: float | None,
    ):

        if which not in ("low", "high"):
            raise ValueError(which)

        if value is not None:
            value = float(value)

            if not np.isfinite(value):
                return

            other_key = "high" if which == "low" else "low"

            other = self.statistic_manual_clim[other_key]

            if other is not None:
                if which == "low" and value >= other:
                    return

                if which == "high" and value <= other:
                    return

        self.statistic_manual_clim[which] = value

        self._update_statistic_colorbar()
        self._update_statistic_colors()

    def _colors_for_record(
        self,
        key,
        record,
    ):
        # Statistic coloring takes precedence
        if self.neuron_statistic_values is not None:
            return (
                self._statistic_colors_for_record(record),
                "default",
            )

        # Tracked overview: union contains everything
        if key == "union":
            return (
                self._tracked_union_colors(record),
                "default",
            )

        # Session overview: ordinary session color
        return (
            record.color,
            "default",
        )

    def _statistic_colors_for_record(
        self,
        record: OverviewRecord,
    ):

        ids = np.asarray(record.ids, dtype=int)

        point_values = np.full(ids.shape, np.nan, dtype=float)

        if self.neuron_statistic_values is not None:

            valid_ids = (ids >= 0) & (ids < len(self.neuron_statistic_values))

            point_values[valid_ids] = self.neuron_statistic_values[ids[valid_ids]]

        opts = self.styles.overview

        nan_color = np.asarray(
            color.Color(opts["statistic_nan_color"]).rgba,
            dtype=np.float32,
        )

        nan_color[3] = opts["statistic_nan_alpha"]

        rgba = np.tile(nan_color, (len(ids), 1))

        if self.statistic_data_clim is None or self.neuron_statistic_values is None:
            return rgba

        finite = np.isfinite(point_values)

        if not np.any(finite):
            return rgba

        clim = self._effective_statistic_clim()

        lo, hi = clim
        # lo, hi = self.statistic_data_clim

        if hi > lo:
            normalized = (point_values[finite] - lo) / (hi - lo)
        else:
            normalized = np.full(np.count_nonzero(finite), 0.5)

        normalized = np.clip(normalized, 0.0, 1.0)

        rgba[finite] = self.statistic_cmap.map(normalized).astype(np.float32)

        if (
            self.display_mode == "tracked_overview"
            and record is self.plotting["data"].get("union")
            and self.state.current_session_id is not None
        ):

            current = self.state.assignments[:, self.state.current_session_id] >= 0

            ids = np.asarray(record.ids, dtype=int)

            valid_ids = (ids >= 0) & (ids < len(current))

            point_in_current = np.zeros(len(ids), dtype=bool)

            point_in_current[valid_ids] = current[ids[valid_ids]]

            # Neurons not present in current session remain visible,
            # but substantially dimmer.
            rgba[~point_in_current, 3] *= opts["tracked_stat_other_alpha_scale"]

        return rgba

    def _point_near(
        self,
        pos,
        target,
        *,
        radius_x=12,
        radius_y=10,
    ):
        return (
            abs(pos[0] - target[0]) <= radius_x and abs(pos[1] - target[1]) <= radius_y
        )

    def _colorbar_hit_target(self, pos):

        if not self.statistic_colorbar.visible:
            return None

        # Reset controls have priority.
        if self.statistic_colorbar_low_reset.visible and self._point_near(
            pos, self._cbar_low_reset_pos
        ):
            return "reset_low"

        if self.statistic_colorbar_high_reset.visible and self._point_near(
            pos, self._cbar_high_reset_pos
        ):
            return "reset_high"

        if self._point_near(pos, self._cbar_low_label_pos, radius_x=25, radius_y=12):
            return "low"

        if self._point_near(pos, self._cbar_high_label_pos, radius_x=25, radius_y=12):
            return "high"

        return None

    def _update_colorbar_hover(self, target):

        low_hover = target == "reset_low"
        high_hover = target == "reset_high"

        self.statistic_colorbar_low_reset.color = "#c62828" if low_hover else "#707070"

        self.statistic_colorbar_high_reset.color = (
            "#c62828" if high_hover else "#707070"
        )

        self.statistic_colorbar_low_reset.font_size = 13 if low_hover else 11
        self.statistic_colorbar_high_reset.font_size = 13 if high_hover else 11

    ### =========================== COLORSTYLES ============================ ###

    def _make_statistic_colormap(
        self,
        name: str,
        reverse: bool,
    ):
        spec = STATISTIC_CMAPS[name]

        if isinstance(spec, str):
            base = color.get_colormap(spec)
        else:
            base = color.Colormap(spec)

        x = np.linspace(0.0, 1.0, 256)

        if reverse:
            x = x[::-1]

        # Always return a fresh deterministic colormap.
        return color.Colormap(base.map(x))

    def _rebuild_statistic_colorbar_gradient(self):

        was_visible = (
            self.statistic_colorbar.visible
            if self.statistic_colorbar is not None
            else False
        )

        if self.statistic_colorbar is not None:
            self.statistic_colorbar.parent = None

        self.statistic_colorbar = visuals.ColorBar(
            cmap=self.statistic_cmap,
            orientation="bottom",
            size=self._cbar_size,
            pos=self._cbar_center,
            label="",
            clim=("", ""),
            border_width=1,
            border_color="black",
            parent=self.scene,
        )

        self.statistic_colorbar.order = 10001
        self.statistic_colorbar.visible = was_visible

    def set_statistic_colormap(
        self,
        name: str,
        *,
        reverse: bool = False,
    ):
        self.statistic_cmap_name = name
        self.statistic_cmap_reversed = reverse

        self.statistic_cmap = self._make_statistic_colormap(
            name,
            reverse,
        )

        self._rebuild_statistic_colorbar_gradient()
        self._update_statistic_colorbar()
        self._update_statistic_colors()

    def _update_statistic_colorbar(self):

        visible = (
            self.neuron_statistic_values is not None
            and self.statistic_data_clim is not None
        )

        self.statistic_colorbar.visible = visible
        self.statistic_colorbar_bg.visible = visible

        for text in (
            self.statistic_colorbar_low,
            self.statistic_colorbar_high,
            self.statistic_colorbar_title,
        ):
            text.visible = visible

        if not visible:
            return

        clim = self._effective_statistic_clim()

        lo, hi = clim

        lo_text, hi_text = format_colorbar_limits(
            lo,
            hi,
        )

        self.statistic_colorbar_low.text = lo_text
        self.statistic_colorbar_high.text = hi_text

        self.statistic_colorbar_low_reset.visible = (
            visible and self.statistic_manual_clim["low"] is not None
        )

        self.statistic_colorbar_high_reset.visible = (
            visible and self.statistic_manual_clim["high"] is not None
        )

        self.statistic_colorbar_title.text = self._format_colorbar_title(
            self.statistic_title or ""
        )

    def _edit_statistic_clim(
        self,
        which: str,
    ):
        clim = self._effective_statistic_clim()

        current = clim[0] if which == "low" else clim[1]

        value, accepted = QInputDialog.getDouble(
            self.native,
            ("Lower color limit" if which == "low" else "Upper color limit"),
            "Value:",
            current,
            -1e100,
            1e100,
            decimals=6,
        )

        if accepted:
            self.set_statistic_clim_limit(
                which,
                value,
            )

    def _update_statistic_colors(self):
        """
        Recolor existing neuron visuals from the current statistic.

        Does not rebuild positions/footprints.
        """

        for key, record in self.plotting["data"].items():

            visual = self.plotting["visuals"].get(key)

            if visual is None:
                continue
            if (
                self.neuron_statistic_values is not None
                and self.display_mode == "tracked_overview"
                and key != "union"
            ):
                visual.visible = False
                continue

            mask = self._review_mask_for_record(record)

            pos = record.pos[mask]
            if pos.shape[0] == 0:
                visual.visible = False
                continue

            vals = record.vals[mask]

            # -------------------------------------------
            # No statistic selected:
            # restore ordinary overview colors
            # -------------------------------------------
            if self.neuron_statistic_values is None:

                if key == "union":
                    colors = self._tracked_union_colors(record)
                    style = "default"
                else:
                    # colors = self.state.session_colors[key]
                    colors = "white"

                    style = (
                        "default"
                        if key == self.state.current_session_id
                        else "background"
                    )

            # -------------------------------------------
            # Statistic selected
            # -------------------------------------------
            else:
                colors = self._statistic_colors_for_record(record)

                # For now all statistic-colored data use the
                # ordinary visual style. The colors themselves
                # encode the statistic.
                style = "default"

            if (
                isinstance(colors, np.ndarray)
                and colors.ndim == 2
                and len(colors) == len(record.ids)
            ):
                colors = colors[mask]

            plot_options = self.styles.get_plot_options(
                style=style,
                plot_type="marker",
                values=vals,
                colors=colors,
                edge_width=0,
            )

            visual.visible = True
            visual.set_data(pos, **plot_options)

        self.update()

    def _format_colorbar_title(
        self,
        title: str,
    ) -> str:
        return "\n".join(
            textwrap.wrap(
                title,
                width=24,
                break_long_words=False,
            )
        )

    def _tracked_union_colors(
        self,
        record: OverviewRecord,
    ):
        ids = np.asarray(
            record.ids,
            dtype=int,
        )

        opts = self.styles.overview

        # Start with faint neutral colour.
        other = np.asarray(
            color.Color(opts["tracked_other_color"]).rgba,
            dtype=np.float32,
        )
        other[3] = opts["tracked_other_alpha"]

        rgba = np.tile(
            other,
            (len(ids), 1),
        )

        current_session = self.state.current_session_id or 0
        # Current-session neurons get the actual session colour.
        current_color = np.asarray(
            # color.Color(self.state.session_colors[current_session]).rgba,
            color.Color("white").rgba,
            dtype=np.float32,
        )

        current_color[3] = opts["tracked_current_alpha"]

        if (
            self.state.assignments is not None
            and current_session < self.state.assignments.shape[1]
        ):
            current_neurons = self.state.assignments[:, current_session] >= 0

            valid = (ids >= 0) & (ids < len(current_neurons))

            in_current = np.zeros(
                len(ids),
                dtype=bool,
            )
            in_current[valid] = current_neurons[ids[valid]]

            rgba[in_current] = current_color

        return rgba

    ### ==================================================================== ###
    ### ======================= GENERAL STYLE HELPER ======================= ###
    ### ==================================================================== ###

    def update_session_styles(self, session_id):

        if session_id not in self.plotting["visuals"]:
            return

        if session_id == "union":
            self.plotting["visuals"][session_id].visible = True
        else:
            self.plotting["visuals"][session_id].visible = self.data.sessions[
                session_id
            ].active

        self._update_statistic_colors()

    def update_style(self, component, style="default"):

        visuals = self.plotting["overlays"].get(style, [])
        if component is None:
            for vis in visuals:
                vis.visible = False
            self.update()
            return

        if not isinstance(component, list):
            component = [component]

        if self.display_mode == "session_overview":
            key = self.state.current_session_id
        else:
            key = "union"

        if key is None or key not in self.plotting["data"]:
            ## can happen on session unregistration
            self.plotting["overlays"][style][0].visible = False
            self.update()
            return

        neuron_ids = [c.neuron_id for c in component]

        record = self.plotting["data"][key]

        mask = np.isin(record.ids, neuron_ids)
        mask &= self._review_mask_for_record(record)

        # mask = np.isin(self.plotting["data"][key].ids, neuron_ids)
        if not np.any(mask):
            self.plotting["overlays"][style][0].visible = False
            self.update()
            return
        vals = self.plotting["data"][key].vals[mask]
        vals += 0.5

        plot_options = self.styles.get_plot_options(style, "marker", vals, edge_width=0)

        self.plotting["overlays"][style][0].set_data(
            self.plotting["data"][key].pos[mask].astype(np.float32),
            **plot_options,
        )
        self.plotting["overlays"][style][0].visible = True
        self.update()

    def find_closest_component(self, mouse_pos) -> Optional[NeuronComponent]:
        # print("neurons:", self.data.neurons)
        if (
            self.state.current_session_id is None
            or "background" not in self.plotting
            or self.data.assignments is None
            or self.data.assignments.union is None
            or self.data.assignments.union.centroids is None
        ):
            return None

        mouse_pos = click_events.canvas_to_visual(
            self.plotting["background"], mouse_pos
        )

        # union_centroids = np.nanmean(self.data.neurons.centroids, axis=1)
        union_centroids = self.data.assignments.union.centroids

        # find closest footprint
        distances = (union_centroids[:, 0] - mouse_pos[0]) ** 2 + (
            union_centroids[:, 1] - mouse_pos[1]
        ) ** 2

        ## filter results for display based on review status
        neuron_ids = np.arange(len(union_centroids), dtype=int)
        focused_neuron_id = (
            None
            if self.state.focused_component is None
            else self.state.focused_component.neuron_id
        )

        review_mask = ReviewStatusFilter.neuron_mask(
            neuron_ids,
            self.data.assignments.review_status,
            (self.controls["panel"].review_filter.visible_statuses),
            focused_neuron_id=focused_neuron_id,
            keep_focused=True,
        )
        distances[~review_mask] = np.inf

        if self.display_mode == "session_overview":
            mask = self.state.assignments[:, self.state.current_session_id] >= 0
            distances[~mask] = np.inf

        distances[~np.isfinite(distances)] = np.inf
        if not np.any(np.isfinite(distances)):
            return None

        neuron_id = np.argmin(distances).astype(int)
        if np.sqrt(distances[neuron_id]) > 10.0:
            return None

        return NeuronComponent(neuron_id, self.state.current_session_id)

    def on_mouse_move(self, event):

        target = self._colorbar_hit_target(event.pos)

        self._update_colorbar_hover(target)

        if target is not None:
            # Don't hover a neuron underneath the controls.
            QToolTip.hideText()
            event.handled = True
            self.update()
            return

        super().on_mouse_move(event)

    def on_mouse_release(self, event):

        if event.button == 1:

            target = self._colorbar_hit_target(event.pos)

            if target == "reset_low":
                self.set_statistic_clim_limit("low", None)
                event.handled = True
                return

            if target == "reset_high":
                self.set_statistic_clim_limit("high", None)
                event.handled = True
                return

            if target == "low":
                self._edit_statistic_clim("low")
                event.handled = True
                return

            if target == "high":
                self._edit_statistic_clim("high")
                event.handled = True
                return

        super().on_mouse_release(event)

    def _review_mask_for_record(self, record: OverviewRecord) -> np.ndarray:

        ids = np.asarray(record.ids, dtype=int)

        mask = np.zeros(ids.shape, dtype=bool)

        if self.data.assignments is None:
            return mask

        review_status = self.data.assignments.review_status

        valid = (ids >= 0) & (ids < len(review_status))

        if not np.any(valid):
            return mask

        focused_neuron_id = (
            None
            if self.state.focused_component is None
            else self.state.focused_component.neuron_id
        )

        mask[valid] = ReviewStatusFilter.neuron_mask(
            ids[valid],
            review_status,
            (self.controls["panel"].review_filter.visible_statuses),
            focused_neuron_id=focused_neuron_id,
            keep_focused=True,
        )

        return mask


class Controller(BasePlot.CanvasController):

    canvas: Display  # type hint for better code completion

    def build_controls(self):

        self.current_statistic_query = None
        self.statistic_table = None

        self.controls["panel"] = OverviewControlPanel(self.section)
        self.canvas.attach_control_overlay()

        self.controls["statistics"] = StatisticQuerySelector(
            engine=self.data.statistic_engine,
        )
        self.section.x_options_layout.addWidget(self.controls["statistics"])

        self.controls["statistics"].set_default_reduction_provider(
            self._overview_statistic_defaults
        )
        self.controls["statistics"].queryChanged.connect(
            self._on_statistic_query_changed
        )
        self.controls["statistics"].set_query_mode("neuron_bound")

        self.connect_signal(
            self.data.statistic_engine.values_changed,
            self._on_statistics_values_changed,
            controls=True,
        )

        self.controls["stat_cmap_label"] = QLabel("Colormap:")

        self.controls["stat_cmap"] = QComboBox()
        self.controls["stat_cmap"].addItems(STATISTIC_CMAPS.keys())

        self.controls["stat_reverse"] = QCheckBox("Reverse")

        self.section.x_options_layout.addWidget(self.controls["stat_cmap_label"])
        self.section.x_options_layout.addWidget(self.controls["stat_cmap"])
        self.section.x_options_layout.addWidget(self.controls["stat_reverse"])

        self.controls["stat_cmap"].currentTextChanged.connect(
            self._on_statistic_color_options_changed
        )

        self.controls["stat_reverse"].toggled.connect(
            self._on_statistic_color_options_changed
        )

        self.controls["panel"].review_filter.changed.connect(
            self._on_review_filter_changed
        )

    def _on_statistic_query_changed(self, query):
        self.current_statistic_query = query
        self._recalculate_statistic()

    def _on_statistics_values_changed(self, statistic_keys):
        query = self.current_statistic_query

        if query is not None and query.statistic_key in statistic_keys:
            self._recalculate_statistic()

    def _recalculate_statistic(self):
        if self._deactivated:
            return

        self._cancel_background_tasks()

        query = self.current_statistic_query

        if query is None:
            self.statistic_table = None
            self.canvas.set_neuron_statistic_values(
                None,
                title=None,
            )
            return

        revision = self.data.statistic_engine.query_revision(query)

        def evaluate():
            return self.data.statistic_engine.evaluate_table(query)

        self._statistic_task_id = self.state.tasks.start(
            "calculating",
            f"Calculate {query.statistic_key}",
            evaluate,
            on_result=lambda table, query=query, revision=revision: (
                self._on_statistic_ready(query, table, revision)
            ),
            background=True,
        )

    def _on_statistic_ready(self, query, table, revision):
        if self._deactivated:
            return

        if query != self.current_statistic_query:
            return

        if revision != self.data.statistic_engine.query_revision(query):
            return

        self.statistic_table = table

        if table is None:
            self.canvas.set_neuron_statistic_values(
                None,
                title=None,
            )
            return
        values = self._dense_neuron_values(table)

        self.canvas.set_neuron_statistic_values(
            values,
            title=table.stat.title,
        )

    def _dense_neuron_values(self, table):

        neuron_dim = neuron_bound_dim(table.dims)

        if neuron_dim is None:
            raise ValueError(
                "Neuron-bound query returned no neuron dimension: " f"{table.dims}"
            )

        return table.indexed_values(
            neuron_dim,
            self.state.assignments.shape[0],
        )

    def _overview_statistic_defaults(
        self,
        stat_def,
    ):
        reductions = {}

        session_dims = [dim for dim in stat_def.dims if dim in SESSION_DIMS]

        if self.section.display_mode == "session_overview":
            session_id = self.state.current_session_id

            if session_id is not None:
                for dim in session_dims:
                    reductions[dim] = ReductionSpec(
                        "single",
                        index=session_id,
                    )

        elif self.section.display_mode == "tracked_overview":
            for dim in session_dims:
                reductions[dim] = ReductionSpec("mean")

        return reductions

    def _on_statistic_color_options_changed(
        self,
        *_,
    ):
        self.canvas.set_statistic_colormap(
            self.controls["stat_cmap"].currentText(),
            reverse=self.controls["stat_reverse"].isChecked(),
        )

    def initialize_display(self):

        self.canvas.clean()
        self.canvas.initialize_overlays()

        self._on_session_changed()

    def _on_data_changed(self, event: DataChange):
        rebuild = event.has(
            *SESSION_STRUCTURE_CHANGES,
            C.ASSIGNMENT_SET,
            C.ASSIGNMENT_MAPPING,
            C.UNION_GEOMETRY,
            C.FOOTPRINT_GEOMETRY,
            C.BACKGROUND_IMAGE,
            C.INCLUSION,
            C.SESSION_ACTIVITY,
            C.SESSION_METADATA,
        ) or event.has_availability("spatial")

        if rebuild:
            self.initialize_display()
        elif event.has(C.REVIEW_STATUS):
            self._on_review_filter_changed()

    def _on_session_changed(self):
        if (
            self.data.assignments is None
            or self.data.assignments.ids.shape[1] == 0
            or self.state.current_session_id is None
        ):
            return

        self.canvas.plot_background()
        if self.section.display_mode == "tracked_overview":
            if "union" not in self.canvas.plotting["data"]:
                self.canvas.build_neuron_visuals_union()
            self.canvas.clean(with_union=False)

        else:
            self.canvas.clean(with_union=True)

            self.canvas.build_neuron_visuals_session(
                session_id=self.state.current_session_id,
                thr=0.2,
            )

        self.canvas.plot_neurons_visuals()

        super()._on_session_changed()

    def _on_session_style_changed(self, session_id):
        self.canvas.update_session_styles(session_id)

    def _on_selection_changed(self):
        # self.side_menu.update_display()
        super()._on_selection_changed()

    def _on_focus_changed(self):
        self.canvas._update_statistic_colors()
        super()._on_focus_changed()

    def update_neuron_selection(self):
        self.update_styles()

    def _on_review_filter_changed(self):
        self.canvas._update_statistic_colors()
        self.update_styles()

    def deactivate(self):

        if self._deactivated:
            return
        self.canvas.clean()
        super().deactivate()

    def _cancel_background_tasks(self):
        task_id = getattr(self, "_statistic_task_id", None)
        self._statistic_task_id = None

        if task_id is not None:
            self.state.tasks.cancel(task_id)


class OverviewControlPanel(ControlPanel.ControlPanel):

    def __init__(self, parent):
        super().__init__(parent)

        review_selector = self._build_review_selector()
        self.form.addRow("Review status", review_selector)


def sparse_A_to_points(A_csc, dims, thr=0.2):
    """
    A_csc: scipy.sparse.csc_matrix, shape (d, n)
    dims: (H, W)
    Returns:
        pos: (Nnz, 2) float32, (x,y) pixel coords
        roi: (Nnz,) int32, neuron index for each point
        val: (Nnz,) float32, footprint weight
    """
    H, W = dims

    # max_vals = A_csc.max(axis=0).toarray()
    # print("###", max_vals.shape, A_csc.shape)

    # Normalize each column by its 99th percentile

    A = normalize_sparse_array(A_csc, relative_threshold=thr, format="coo")
    pix = A.row.astype(np.int64)
    roi = A.col.astype(np.int32)
    val = A.data.astype(np.float32)
    val /= np.percentile(val, 99) + 1e-8  # normalize to [0,1] for color mapping

    x = (pix // W).astype(np.float32)
    y = (pix % W).astype(np.float32)

    pos = np.column_stack([y, x]).astype(np.float32)  # (Nnz, 2)
    return pos, roi, val


def normalize_sparse_array(
    A, relative_threshold=0.001, minimum_nonzero_entries=10, format="csc"
):
    """
    normalizing sparse arrays with some thresholding
      - relative_threshold: float
          fraction of peak value, at below which entries are considered to be 0
      - minimum_nonzero_entries: int
          minimum number of nonzero entries of the footprint to be considered for further analyses
    """
    return sparse.vstack(
        [
            # a.multiply(a>relative_threshold*a.max())/a.max()  # threshold footprint
            (
                a.multiply(a > (relative_threshold * a.max()))
                / a[a > 0.001 * a.max()].sum()  # threshold footprint
                if (a > 0).sum()
                > minimum_nonzero_entries  # require minimum non-zero entries ...
                else sparse.csr_matrix(a.shape)
            )  # ... otherwise return empty slice
            for a in A.T  # loop through all footprints
        ],
        format=format,
    ).T


def format_colorbar_limits(
    lo: float,
    hi: float,
    significant_digits: int = 4,
) -> tuple[str, str]:

    max_abs = max(abs(lo), abs(hi))

    if max_abs == 0:
        return ("0", "0")

    order = int(np.floor(np.log10(max_abs)))

    if order >= 5 or order <= -4:
        return (
            f"{lo:.{significant_digits - 1}e}",
            f"{hi:.{significant_digits - 1}e}",
        )

    decimals = max(
        0,
        significant_digits - 1 - order,
    )

    return (
        f"{lo:.{decimals}f}",
        f"{hi:.{decimals}f}",
    )
